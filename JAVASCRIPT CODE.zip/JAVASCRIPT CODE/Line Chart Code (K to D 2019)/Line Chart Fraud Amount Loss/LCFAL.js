// Define colors for state categories (regions)
const categoryColors = {
    "West": "rgba(255, 182, 193, 0.7)",  // Light Pink
    "South": "rgba(255, 140, 0, 0.7)",    // Dark Orange
    "Northeast": "rgba(0, 191, 255, 0.7)",    // Deep Sky Blue
    "Midwest": "rgba(75, 0, 130, 0.7)",     // Indigo
    "Capital": "rgba(50, 205, 50, 0.7)"     // Lime Green
};

// Function to generate a line chart for each state category (region)
function createLineChart(data, category, index) {
    // Filter data where is_fraud is 1 and state category matches
    const fraudData = data.filter(d => +d.is_fraud === 1 && d.state_categories === category);

    // Aggregate the fraud loss amount by transaction hour and state category
    const fraudLossByHour = {};
    fraudData.forEach(d => {
        const hour = +d.transaction_hour; // Hour of the transaction
        const lossAmount = +d.fraud_loss_amount || 0; // Ensure the loss amount is numeric

        if (!fraudLossByHour[hour]) {
            fraudLossByHour[hour] = 0;
        }
        fraudLossByHour[hour] += lossAmount; // Sum fraud loss amounts by hour
    });

    // Prepare data for the line chart
    const hours = Object.keys(fraudLossByHour).sort((a, b) => a - b); // Sort hours in ascending order
    const fraudLossAmounts = hours.map(hour => fraudLossByHour[hour]);

    // Line chart trace for fraud loss amounts
    const trace = {
        x: hours,
        y: fraudLossAmounts,
        type: 'scatter',
        mode: 'lines+markers', // Line chart with markers at each point
        name: category,
        line: { color: categoryColors[category], width: 2 }
    };

    // Layout for the line chart
    const layout = {
        title: {
            text: `<b>${index + 1}. Fraud Loss Amount - ${category}</b>`,
            font: { size: 12 }, // Slightly increased title size
        },
        xaxis: {
            title: {
                text: 'Transaction Hour',
                font: { size: 8 }, // Increased font size for x-axis title
            },
            tickmode: 'linear',
            dtick: 1,
            tickfont: { size: 8 } // Reduced font size for axis tick marks
        },
        yaxis: {
            title: {
                text: 'Fraud Loss Amount (USD)',
                font: { size: 8 }, // Increased font size for y-axis title
            },
            tickfont: { size: 8 } // Reduced font size for axis tick marks
        },
        margin: { t: 30, l: 30, r: 30, b: 30 },
        height: 185,  // Set height to 185px
        width: 335,   // Set width to 335px
    };

    // Create the line chart
    Plotly.newPlot(`line-chart-${category}`, [trace], layout, { responsive: true });
}

// Load CSV data and generate line charts for each state category (region)
document.getElementById('fileInput').addEventListener('change', function(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(e) {
        const text = e.target.result;
        const data = d3.csvParse(text);

        // Clear previous plots if any
        document.getElementById("plot").innerHTML = "";

        // Create a line chart for each state category (region)
        const stateCategories = [...new Set(data.map(d => d.state_categories))]; // Get unique state categories

        stateCategories.forEach((category, index) => {
            const chartDiv = document.createElement("div");
            chartDiv.className = "line-chart";
            chartDiv.id = `line-chart-${category}`;
            document.getElementById("plot").appendChild(chartDiv);

            createLineChart(data, category, index);
        });
    };

    reader.readAsText(file);
});
