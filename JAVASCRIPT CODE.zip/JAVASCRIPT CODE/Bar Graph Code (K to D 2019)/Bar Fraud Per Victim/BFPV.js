// Define colors for state categories (regions)
const categoryColors = {
    "West": "rgba(255, 182, 193, 0.7)",  // Light Pink
    "South": "rgba(255, 140, 0, 0.7)",    // Dark Orange
    "Northeast": "rgba(0, 191, 255, 0.7)",    // Deep Sky Blue
    "Midwest": "rgba(75, 0, 130, 0.7)",     // Indigo
    "Capital": "rgba(50, 205, 50, 0.7)"     // Lime Green
};

// Function to generate a bar chart for each state category (region)
function createBarChart(data, category, index) {
    // Filter data where is_fraud is 1 and state category matches
    const fraudData = data.filter(d => +d.is_fraud === 1 && d.state_categories === category);

    // Aggregate the fraud per victim by state
    const fraudPerVictimByState = {};
    fraudData.forEach(d => {
        const state = d.state;
        const fraudPerVictim = +d.fraud_per_victim || 0; // Ensure the fraud per victim value is numeric
        if (!fraudPerVictimByState[state]) {
            fraudPerVictimByState[state] = 0;
        }
        fraudPerVictimByState[state] += fraudPerVictim; // Sum fraud per victim for each state
    });

    // Prepare data for the bar chart
    const states = Object.keys(fraudPerVictimByState);
    const fraudPerVictimValues = states.map(state => fraudPerVictimByState[state]);

    // Bar chart trace for fraud per victim values
    const trace = {
        x: states,
        y: fraudPerVictimValues,
        type: 'bar',
        name: 'Fraud Per Victim',
        marker: { color: categoryColors[category] } // Unique color for each region
    };

    // Layout for the bar chart
    const layout = {
        title: {
            text: `<b>${index + 1}. Fraud Per Victim - ${category}</b>`,
            font: { size: 10 }, // Reduced font size for title
        },
        xaxis: {
            title: {
                text: 'State',
                font: { size: 8 },  // Reduced font size for x-axis title
            }
        },
        yaxis: {
            title: {
                text: 'Fraud Per Victim (USD)',
                font: { size: 8 },  // Reduced font size for y-axis title
            }
        },
        margin: { t: 40, l: 40, r: 40, b: 40 },
        height: 200,  // Adjusted height for compactness
        width: 280,   // Adjusted width for smaller charts
    };

    // Create the bar chart
    Plotly.newPlot(`bar-chart-${category}`, [trace], layout, { responsive: true });
}

// Load CSV data and generate bar charts for each state category (region)
document.getElementById('fileInput').addEventListener('change', function(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(e) {
        const text = e.target.result;
        const data = d3.csvParse(text);

        // Clear previous plots if any
        document.getElementById("plot").innerHTML = "";

        // Create a bar chart for each state category (region)
        const stateCategories = [...new Set(data.map(d => d.state_categories))]; // Get unique state categories

        stateCategories.forEach((category, index) => {
            const chartDiv = document.createElement("div");
            chartDiv.className = "bar-chart";
            chartDiv.id = `bar-chart-${category}`;
            document.getElementById("plot").appendChild(chartDiv);

            createBarChart(data, category, index);
        });
    };

    reader.readAsText(file);
});
