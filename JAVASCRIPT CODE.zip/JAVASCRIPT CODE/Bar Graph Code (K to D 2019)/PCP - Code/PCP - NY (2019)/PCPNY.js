document.getElementById('fileInput').addEventListener('change', function(event) {
    const file = event.target.files[0];
    if (!file) {
        return;
    }
    if (file.type !== "text/csv") {
        document.getElementById('error-message').innerText = "Please upload a valid CSV file.";
        return;
    }
    const reader = new FileReader();
    reader.onload = function(e) {
        const text = e.target.result;
        const parsedData = d3.csvParse(text);
        processData(parsedData);
    };
    reader.readAsText(file);
});

function processData(rawData) {
    const highFraudCitiesNY = ["New York City", "Howes Cave", "Melville", "Garrattsville", "Jordanville"];
    const filteredData = rawData.filter(d =>
        d.state === "NY" &&
        highFraudCitiesNY.includes(d.city) &&
        d.is_fraud !== undefined &&
        d.category &&
        d.generation &&
        d.job_categories
    );

    if (filteredData.length === 0) {
        document.getElementById('error-message').innerText = "No valid data points found.";
        return;
    } else {
        document.getElementById('error-message').innerText = "";
    }

    const cityCategories = [...new Set(filteredData.map(d => d.city))];
    const jobCategories = [...new Set(filteredData.map(d => d.job_categories))];
    const generationCategories = [...new Set(filteredData.map(d => d.generation))];
    const categoryCategories = [...new Set(filteredData.map(d => d.category))];

    const trace = {
        type: 'parcoords',
        dimensions: [
            {
                label: 'City',
                values: filteredData.map(d => cityCategories.indexOf(d.city)),
                tickvals: cityCategories.map((_, i) => i),
                ticktext: cityCategories,
                thickness: 5,
            },
            {
                label: 'Is Fraud',
                values: filteredData.map(d => +d.is_fraud),
                tickvals: [0, 1],
                ticktext: ['0', '1'],
                thickness: 5,
            },
            {
                label: 'Category',
                values: filteredData.map(d => categoryCategories.indexOf(d.category)),
                tickvals: categoryCategories.map((_, i) => i),
                ticktext: categoryCategories,
                thickness: 5,
            },
            {
                label: 'Generation',
                values: filteredData.map(d => generationCategories.indexOf(d.generation)),
                tickvals: generationCategories.map((_, i) => i),
                ticktext: generationCategories,
                thickness: 5,
            },
            {
                label: 'Job Categories',
                values: filteredData.map(d => jobCategories.indexOf(d.job_categories)),
                tickvals: jobCategories.map((_, i) => i),
                ticktext: jobCategories,
                thickness: 5,
            }
        ],
        line: {
            color: filteredData.map(d => +d.is_fraud),
            colorscale: [[0, '#007acc'], [1, 'yellow']],
            showscale: true,
            width: 1
        }
    };

    const data = [trace];

    const layout = {
        title: {
            text: 'Fraud Analysis for High Fraud Cities in NY',
            font: {
                size: 20
            },
            pad: { t: 40 }
        },
        height: 600,
        width: 1200,
        plot_bgcolor: '#f2f2f2',
        margin: { t: 80, b: 60, l: 80, r: 40 },
        font: {
            size: 16
        }
    };

    Plotly.newPlot('plot', data, layout);
}
