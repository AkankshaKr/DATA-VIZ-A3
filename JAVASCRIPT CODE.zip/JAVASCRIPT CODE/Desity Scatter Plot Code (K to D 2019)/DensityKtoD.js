document.getElementById('fileInput').addEventListener('change', function(event) {
    const file = event.target.files[0];
    if (!file) {
        return;
    }
    if (file.type !== "text/csv") {
        document.getElementById('error-message').innerText = "Please upload a valid CSV file.";
        return;
    }
    const reader = new FileReader();
    reader.onload = function(e) {
        const text = e.target.result;
        const parsedData = d3.csvParse(text);
        processData(parsedData);
    };
    reader.readAsText(file);
});

function processData(rawData) {
    // Filter data where is_fraud == 1
    const filteredData = rawData.filter(d => d.is_fraud === "1");

    // Extract fraud_loss_amount and fraud_victim_count
    const x = filteredData.map(d => +d.fraud_victim_count);
    const y = filteredData.map(d => +d.fraud_loss_amount);

    // Generate a scatter plot
    const trace = {
        x: x,
        y: y,
        mode: 'markers',
        type: 'scatter',
        marker: {
            size: 8,
            color: 'rgb(93, 164, 214)',
            opacity: 0.7
        }
    };

    const layout = {
        title: 'Density Scatter Plot - Fraud Loss Amount vs Fraud Victim Count',
        xaxis: {
            title: 'Fraud Victim Count'
        },
        yaxis: {
            title: 'Fraud Loss Amount'
        },
        height: 600,
        width: 1200,
        plot_bgcolor: '#f2f2f2'
    };

    Plotly.newPlot('plot', [trace], layout);
}
