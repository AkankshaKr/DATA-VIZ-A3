document.getElementById('fileInput').addEventListener('change', function(event) {
    const file = event.target.files[0];
    if (!file) {
        return;
    }
    if (file.type !== "text/csv") {
        document.getElementById('error-message').innerText = "Please upload a valid CSV file.";
        return;
    }
    const reader = new FileReader();
    reader.onload = function(e) {
        const text = e.target.result;
        const parsedData = d3.csvParse(text);
        processData(parsedData);
    };
    reader.readAsText(file);
});

function processData(rawData) {
    // High-Fraud Cities in TX
    const highFraudCities = ["Dallas", "Lolita", "Houston", "Meridian", "Roma"];

    // Filter data for high-fraud cities and is_fraud == 1
    const filteredData = rawData.filter(d => 
        highFraudCities.includes(d.city) && 
        d.is_fraud === "1" && 
        d.rounded_amt !== undefined
    );

    // Ensure all cities are represented, even if no data points exist
    const traces = highFraudCities.map(city => {
        const cityData = filteredData
            .filter(d => d.city === city)
            .map(d => +d.rounded_amt);

        return {
            type: 'violin',
            y: cityData.length > 0 ? cityData : [null], // Handle missing data
            x: Array(cityData.length > 0 ? cityData.length : 1).fill(city),
            name: city,
            box: { visible: true },
            meanline: { visible: true },
            points: cityData.length > 0 ? 'all' : false, // Only show points if data exists
            jitter: 0.5
        };
    });

    // Define the layout
    const layout = {
        title: 'Violin Plot - Fraud Rounded Amount for High-Fraud Cities in TX (is_fraud=1)',
        xaxis: { title: 'City', type: 'category' },
        yaxis: { title: 'Rounded Amount', zeroline: false },
        showlegend: false,
        height: 600,
        width: 1200,
        plot_bgcolor: '#f2f2f2',
    };

    // Plot the data
    Plotly.newPlot('plot', traces, layout);
}
