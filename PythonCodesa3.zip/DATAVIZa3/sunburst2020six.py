import pandas as pd
import plotly.express as px

# Load the dataset
file_path = r"D:\Data Visualization\Digital Society - A1\A1 Refined Dataset - Dataset.csv"
data = pd.read_csv(file_path)

# Filter data for states NY, TX, PA, CA, SC, VA and is_fraud = 1
filtered_data = data[
    (data['state'].isin(['NY', 'TX', 'PA', 'CA', 'SC', 'VA'])) & (data['is_fraud'] == 1)
]

# Define updated pastel colors for each state
state_colors = {
    'NY': '#FFB6C1',    # Light pink (pastel)
    'TX': '#FFA07A',    # Light salmon (orangish pastel)
    'PA': '#20B2AA',    # TealGreen (teal green pastel)
    'CA': '#FFD700',    # Gold (yellow pastel)
    'SC': '#F0E68C',    # Khaki (light yellow pastel)
    'VA': '#98FB98'     # PaleGreen (green pastel)
}

# Create a Sunburst chart for job_categories by city
fig = px.sunburst(
    filtered_data,
    path=['state', 'city', 'job_categories'],  # Hierarchical path: State > City > Job Categories
    values=None,                               # Using the count of occurrences for size
    title="Sunburst Chart: Job Categories by State and City of 2020(Fraud Cases in NY, TX, PA, CA, SC, VA)",
    color='state',                             # Set color based on the state
    color_discrete_map=state_colors            # Use custom pastel colors for states
)

# Display the Sunburst chart
fig.show()
