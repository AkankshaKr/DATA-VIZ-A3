import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler, LabelEncoder

# Load your dataset
file_path = r"C:\Users\Acer\Downloads\updated_dataset.csv"
data = pd.read_csv(file_path)

# Drop non-informative or high-cardinality columns
columns_to_drop = ['Unnamed', 'cc_num', 'unix_time', 'zip']  # Adjust as needed
data = data.drop(columns=columns_to_drop, errors='ignore')

# Select relevant columns
selected_columns = ['is_fraud', 'rounded_amt', 'transaction_hour', 'age', 'transaction_month']
data = data[selected_columns]

# Normalize the numeric data
scaler = StandardScaler()
normalized_data = pd.DataFrame(scaler.fit_transform(data), columns=data.columns)

# Calculate the covariance matrix
covariance_matrix = normalized_data.cov()

# Visualize the covariance matrix with annotations and rounded values
plt.figure(figsize=(8, 6))  # Adjust figure size
sns.heatmap(
    covariance_matrix,
    annot=True,         # Enable annotations
    fmt=".2f",         # Format to 2 decimal places
    cmap="coolwarm",
    cbar=True,
    xticklabels=True,
    yticklabels=True
)

# Rotate x-axis labels
plt.xticks(rotation=45, ha="right")
plt.yticks(rotation=0)

# Add title
plt.title("Covariance Matrix Heatmap for Selected Variables")
plt.tight_layout()  # Ensure the plot fits well
plt.show()
