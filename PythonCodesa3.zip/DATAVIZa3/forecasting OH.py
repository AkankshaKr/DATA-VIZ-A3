import pandas as pd
from statsmodels.tsa.arima.model import ARIMA
import matplotlib.pyplot as plt
from pmdarima import auto_arima  # For automated ARIMA parameter tuning

# Load the dataset
file_path = r"C:\Users\Acer\Downloads\updated_dataset.csv"
data = pd.read_csv(file_path, low_memory=False)

# Filter for fraudulent transactions only
fraud_data = data[data['is_fraud'] == 1].copy()

# Ensure 'transaction_date' is parsed correctly
fraud_data['transaction_date'] = pd.to_datetime(
    fraud_data['transaction_date'], dayfirst=True, errors='coerce'
)

# Drop rows where 'transaction_date' couldn't be parsed
fraud_data = fraud_data.dropna(subset=['transaction_date'])

# Filter data for the state of interest: NY
ny_data = fraud_data[fraud_data['state'] == "OH"]

# Check if OH data is empty
if ny_data.empty:
    print("No data available for state: OH")
else:
    # Group by date and count fraudulent transactions
    ny_data = ny_data.groupby('transaction_date').size().reset_index(name='fraud_count')

    # Resample the data to daily frequency and fill missing dates with 0
    ny_data = ny_data.set_index('transaction_date').resample('D').sum()
    ny_data['fraud_count'] = ny_data['fraud_count'].fillna(0)

    # Train-test split: Use the last 30 days for testing
    train = ny_data['fraud_count'][:-30]
    test = ny_data['fraud_count'][-30:]

    # Check if the training data is sufficient
    if len(train) < 10:  # Arbitrary threshold for ARIMA
        print("Not enough data to train ARIMA model for state: OH")
    else:
        # Automatically determine ARIMA parameters
        auto_model = auto_arima(
            train,
            seasonal=False,
            trace=True,
            error_action='ignore',
            suppress_warnings=True,
            stepwise=True
        )
        order = auto_model.order
        print(f"Selected ARIMA Order: {order}")

        # Fit the ARIMA model
        model = ARIMA(train, order=order)
        model_fit = model.fit()

        # Forecast for the test period
        forecast = model_fit.forecast(steps=len(test))

        # Plot the actual vs forecasted values
        plt.figure(figsize=(12, 6))
        plt.plot(train.index, train, label='Training Data')
        plt.plot(test.index, test, label='Test Data', color='orange')
        plt.plot(test.index, forecast, label='Forecast', color='green', linestyle='--')
        plt.title('Fraud Forecasting for OH', fontsize=16)
        plt.xlabel('Date', fontsize=14)
        plt.ylabel('Fraudulent Transactions Count', fontsize=14)
        plt.legend()
        plt.grid(True, linestyle='--', alpha=0.6)
        plt.show()

        # Print forecasted values
        print("Forecasted Fraudulent Transactions for OH:")
        print(forecast)



#Evaluate Model Performance
from sklearn.metrics import mean_absolute_error, mean_squared_error
import numpy as np

# Calculate evaluation metrics
mae = mean_absolute_error(test, forecast)
rmse = np.sqrt(mean_squared_error(test, forecast))

print(f"Mean Absolute Error (MAE): {mae}")
print(f"Root Mean Squared Error (RMSE): {rmse}")

#Feature Engineering: Add Time-Based Features
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Ensure 'transaction_date' is in datetime format
fraud_data['transaction_date'] = pd.to_datetime(fraud_data['transaction_date'])

# Step 1: Compute daily fraud counts
fraud_aggregated = fraud_data.groupby(fraud_data['transaction_date'].dt.date)['is_fraud'].sum().reset_index()
fraud_aggregated.columns = ['transaction_date', 'fraud_count']

# Step 2: Add 'day_of_week' feature
fraud_aggregated['transaction_date'] = pd.to_datetime(fraud_aggregated['transaction_date'])
fraud_aggregated['day_of_week'] = fraud_aggregated['transaction_date'].dt.dayofweek  # 0=Monday, 6=Sunday

# Step 3: Boxplot using the aggregated data
plt.figure(figsize=(12, 6))
sns.boxplot(x='day_of_week', y='fraud_count', data=fraud_aggregated)
plt.title('Fraud Count by Day of the Week', fontsize=16)
plt.xlabel('Day of the Week', fontsize=14)
plt.ylabel('Fraud Count', fontsize=14)
plt.xticks(ticks=range(7), labels=['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'])
plt.show()

#Test Seasonal ARIMA (SARIMA)
from statsmodels.tsa.statespace.sarimax import SARIMAX

# Fit a Seasonal ARIMA model if seasonality is suspected
sarima_model = SARIMAX(train, order=(1, 0, 1), seasonal_order=(1, 1, 0, 7))
sarima_fit = sarima_model.fit(disp=False)

# Forecast
sarima_forecast = sarima_fit.forecast(steps=len(test))

# Plot
plt.figure(figsize=(12, 6))
plt.plot(train.index, train, label='Training Data')
plt.plot(test.index, test, label='Test Data', color='orange')
plt.plot(test.index, sarima_forecast, label='SARIMA Forecast', color='green', linestyle='--')
plt.title('SARIMA Forecast for OH', fontsize=16)
plt.xlabel('Date', fontsize=14)
plt.ylabel('Fraudulent Transactions Count', fontsize=14)
plt.legend()
plt.grid(True, linestyle='--', alpha=0.6)
plt.show()

# Evaluate SARIMA Model Performance
from sklearn.metrics import mean_absolute_error, mean_squared_error
import numpy as np

# Calculate evaluation metrics
sarima_mae = mean_absolute_error(test, sarima_forecast)
sarima_rmse = np.sqrt(mean_squared_error(test, sarima_forecast))

print(f"SARIMA Model Performance:")
print(f"Mean Absolute Error (MAE): {sarima_mae}")
print(f"Root Mean Squared Error (RMSE): {sarima_rmse}")


# Calculate residuals (errors)
sarima_residuals = test - sarima_forecast

# Plot residuals
plt.figure(figsize=(12, 6))
plt.hist(sarima_residuals, bins=20, color='skyblue', edgecolor='black')
plt.title('SARIMA Model Residuals Distribution', fontsize=16)
plt.xlabel('Residuals', fontsize=14)
plt.ylabel('Frequency', fontsize=14)
plt.grid(True, linestyle='--', alpha=0.6)
plt.show()


