import pandas as pd

# Upload the dataset
file_path = r"C:\Users\Acer\Downloads\archive\credit_card_transactions.csv"

# Load the dataset into a DataFrame
df = pd.read_csv(file_path)

# Displaying first few rows
print(df.head())


# Get dataframe shapes
print('Shape of creditcard dataframe:', df.shape)


# Get train data info: count, feature names, data types, missing data counts
print('------------------ creditcard Dataframe info------------------')
print(df.info())

# Get statistical summaries for each feature
print('------------------creditcard Dataframe describe------------------')
print(df.describe())

# Check for duplicate rows
duplicates = df.duplicated()

# Count of duplicate rows
duplicate_count = duplicates.sum()
print(f'Number of duplicate rows: {duplicate_count}')

# Optional: Remove duplicate rows
df = df.drop_duplicates()

# Next, Extracting values from the 924,850th index to the end
df_cut = df.iloc[:924849]

# Resetting Index
df_cut.reset_index(drop=True, inplace=True)

print(df_cut.head())

## Dropping the last column
df_cut = df_cut.drop(df_cut.columns[-1], axis=1)

# Checking if the column is actually removed
print(df_cut.head())

# Ensure the dob column is in datetime format
df_cut['dob'] = pd.to_datetime(df_cut['dob'])

reference_date = pd.to_datetime('2020-12-31')

# Calculate the age
df_cut['age'] = (reference_date - df_cut['dob']).dt.days // 365.25

print(df_cut[['dob', 'age']].head())

# Identify missing data
print("Missing data:\n", df_cut.isnull().sum())

# Display unique job titles in the 'job' column
unique_jobs = df_cut['job'].unique()

# Print the unique job titles
print(unique_jobs)


# Save the processed DataFrame as a CSV file
output_file_path = r"C:\Users\Acer\Downloads\processed_credit_card_transactions.csv"
df_cut.to_csv(output_file_path, index=False)
print(f"Processed data saved to {output_file_path}")
























import pandas as pd
# Replace 'your_file_path.csv' with the actual path of your dataset
file_path = r"C:\Users\Acer\Downloads\processed_credit_card_transactions.csv"
df = pd.read_csv(file_path)



# Display the first few rows to verify the data
print(df.head())


# Assuming your DataFrame is named df
unique_values = df['job'].nunique()

print(f"Number of unique job: {unique_values}")


# Get the count of each unique job category
job_counts = df['job'].value_counts()
print("\nCount of each job :")
print(job_counts)


# Split the 'trans_date_trans_time' column into 'transaction_date' and 'transaction_time'
df[['transaction_date', 'transaction_time']] = df['trans_date_trans_time'].str.split(' ', expand=True)

# Display the updated DataFrame
print(df.head())



# Change 'transaction_date' to the format 'ddmmyyyy'
df['transaction_date'] = pd.to_datetime(df['transaction_date']).dt.strftime('%d%m%Y')

# Display the updated DataFrame
print(df[['transaction_date']].head())


# Format 'transaction_date' to 'dd-mm-yyyy'
df['transaction_date'] = pd.to_datetime(df['transaction_date'], format='%d%m%Y').dt.strftime('%d-%m-%Y')

# Display the updated DataFrame
print(df[['transaction_date']].head())


# Convert 'transaction_time' to datetime format (if not already)
df['transaction_time'] = pd.to_datetime(df['transaction_time'], format='%H:%M:%S')

# Extract the hour from 'transaction_time'
df['transaction_hour'] = df['transaction_time'].dt.hour

# Display the updated DataFrame
print(df[['transaction_time', 'transaction_hour']].head())



# Ensure 'transaction_date' is in datetime format with the correct format string
df['transaction_date'] = pd.to_datetime(df['transaction_date'], format='%d-%m-%Y')

# Extract the month from 'transaction_date'
df['transaction_month'] = df['transaction_date'].dt.month

# Display the updated DataFrame
print(df[['transaction_date', 'transaction_month']].head())



# Round off the 'amt' column to the nearest integer and create a new column 'rounded_amt'
df['rounded_amt'] = df['amt'].round()

# Display the updated DataFrame with both original 'amt' and new 'rounded_amt' columns
print(df[['amt', 'rounded_amt']].head())



# Define a function to categorize the age into generations
def categorize_generation(age):
    if 79 <= age <= 103:
        return 'Silent Generation'
    elif 60 <= age <= 78:
        return 'Baby Boomers'
    elif 45 <= age <= 59:
        return 'Generation X'
    elif 30 <= age <= 44:
        return 'Millennials'
    elif 12 <= age <= 29:
        return 'Generation Z'
    else:
        return 'Unknown'  # For any ages outside the defined ranges

# Apply the function to the 'age' column to create a new 'generation' column
df['generation'] = df['age'].apply(categorize_generation)

# Display the result to check the new 'generation' column
print(df[['age', 'generation']].head())


# First, ensure 'transaction_time' is in datetime format (this will automatically handle 12-hour to 24-hour conversion if needed)
df['transaction_time'] = pd.to_datetime(df['transaction_time'], errors='coerce')

# Now, format it to a 24-hour time string (HH:mm:ss)
df['transaction_time_24hr'] = df['transaction_time'].dt.strftime('%H:%M:%S')

# Display the result to check the conversion
print(df[['transaction_time', 'transaction_time_24hr']].head())


# View the columns of the DataFrame
print(df.columns)


# Drop the 'transaction_hour' column from the DataFrame
df = df.drop(columns=['transaction_hour'])

# Display the DataFrame to confirm the column has been removed
print(df.head())


# Ensure 'transaction_time_24hr' is in datetime format
df['transaction_time_24hr'] = pd.to_datetime(df['transaction_time_24hr'], format='%H:%M:%S')

# Extract the hour from 'transaction_time_24hr'
df['transaction_hour'] = df['transaction_time_24hr'].dt.hour

# Display the updated DataFrame with the extracted hour
print(df[['transaction_time_24hr', 'transaction_hour']].head())



# Filter the DataFrame to show rows where 'transaction_hour' is 14
transactions_at_14 = df[df['transaction_hour'] == 14]

# Display the rows with transactions at 14:00 (2:00 PM)
print(transactions_at_14)


# Convert 'transaction_date' to datetime and format it to 'dd-mm-yyyy'
df['transaction_date'] = pd.to_datetime(df['transaction_date']).dt.strftime('%d-%m-%Y')

# Drop the date part from 'transaction_time' (keeping only the time) and make sure it's in 24-hour format
df['transaction_time'] = pd.to_datetime(df['transaction_time']).dt.strftime('%H:%M:%S')

# Display the updated dataframe to check the changes
print(df[['transaction_date', 'transaction_time']].head())


# Display the first few rows of the entire dataset
print(df.head())


# Convert 'transaction_time_24hr' to time format and remove the date part
df['transaction_time_24hr'] = pd.to_datetime(df['transaction_time_24hr']).dt.time

# Display the updated dataframe
print(df[['transaction_time_24hr', 'transaction_hour']].head())


# Filter the dataframe where the transaction_hour is 15
df_15_hour = df[df['transaction_hour'] == 15]

# Display the filtered rows
print(df_15_hour[['transaction_time_24hr', 'transaction_hour']].head())



# Display the updated dataframe
print(df.head())

# Round off the 'amt' column to the nearest integer and create a new column 'rounded_amt'
df['rounded_amt'] = df['amt'].round()

# Remove the original 'amt' column
df = df.drop(columns=['amt'])

# Display the updated DataFrame with the 'rounded_amt' column only
print(df[['rounded_amt']].head())






