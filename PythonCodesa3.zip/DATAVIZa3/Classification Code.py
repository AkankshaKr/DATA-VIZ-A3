import pandas as pd

# Load the dataset
file_path = r"C:\Users\Ketki\Downloads\updated_dataset.csv"
df = pd.read_csv(file_path)

# Check the first few rows of the dataset to understand its structure
print(df.head())

# Subset of the data (e.g., 10% of the dataset)
df_subset = df.sample(frac=0.1, random_state=42)  # 10% of data, adjust as needed

# Check the subset size
print(f"Subset size: {df_subset.shape}")

# Define the target variable (assuming you're predicting 'is_fraud')
target = 'is_fraud'

# Define the features (excluding target and any irrelevant columns)
features = df_subset.drop(columns=[target, 'cluster'], errors='ignore')  # Exclude target and cluster

# Separate into X (features) and y (target)
X = features
y = df_subset[target]

from sklearn.model_selection import train_test_split

# Split the data into training and testing sets (80% train, 20% test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

print(f"Training set size: {X_train.shape}")
print(f"Test set size: {X_test.shape}")


from sklearn.ensemble import RandomForestClassifier  # Import the RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, classification_report


from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

# List of categorical columns (example: 'gender', 'job')
categorical_columns = ['gender', 'job_categories', 'state',]

# List of numerical columns (example: 'age', 'rounded_amt')
numerical_columns = ['age', 'rounded_amt', 'transaction_hour']  # Adjust as needed

# Preprocessing pipeline
preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), numerical_columns),  # Scaling numerical features
        ('cat', OneHotEncoder(), categorical_columns)   # Encoding categorical features
    ])

# Create a pipeline that applies preprocessing and then fits the classifier
pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', RandomForestClassifier(random_state=42))  # Example classifier
])

from sklearn.ensemble import RandomForestClassifier

# Train the model using the pipeline
pipeline.fit(X_train, y_train)

# Save the plot as a PNG file
output_path = r"C:\Users\Ketki\Downloads\ Train the model using the pipeline.png"  # Specify the desired output path
plt.savefig(output_path, format='png', dpi=300, bbox_inches='tight')  # Save as PNG with high resolution

from sklearn.metrics import accuracy_score, classification_report

# Predict on the test set
y_pred = pipeline.predict(X_test)

# Evaluate accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy}")

# Detailed classification report
print(classification_report(y_test, y_pred))

from sklearn.ensemble import RandomForestClassifier

# Train the model with class weight adjustment
pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', RandomForestClassifier(random_state=42, class_weight='balanced'))  # Apply class_weight='balanced'
])

# Fit the model
pipeline.fit(X_train, y_train)
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score

# Predict on the test set
y_pred = pipeline.predict(X_test)

# Generate classification report
print(classification_report(y_test, y_pred))

# Confusion Matrix
print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))

# ROC AUC Score (for binary classification)
roc_auc = roc_auc_score(y_test, pipeline.predict_proba(X_test)[:, 1])
print(f"ROC AUC Score: {roc_auc}")

# Predict probabilities
y_prob = pipeline.predict_proba(X_test)[:, 1]

# Adjust decision threshold (e.g., 0.3)
y_pred_adjusted = (y_prob >= 0.5).astype(int)

# Evaluate with new threshold
print(classification_report(y_test, y_pred_adjusted))

# Adjust decision threshold (e.g., 0.3 instead of 0.5)
y_prob = pipeline.predict_proba(X_test)[:, 1]
y_pred_adjusted = (y_prob >= 0.3).astype(int)

# Evaluate with the adjusted threshold
print(classification_report(y_test, y_pred_adjusted))

# Adjust decision threshold
y_pred_adjusted = (y_prob >= 0.2).astype(int)
print(classification_report(y_test, y_pred_adjusted))

from sklearn.metrics import precision_recall_curve
import matplotlib.pyplot as plt

precision, recall, thresholds = precision_recall_curve(y_test, y_prob)
plt.plot(recall, precision)
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.title('Precision-Recall Curve')
# Save the plot as a PNG file
output_path = r"C:\Users\Ketki\Downloads\Precision-Recall Curve.png"  # Specify the desired output path
plt.savefig(output_path, format='png', dpi=300, bbox_inches='tight')  # Save as PNG with high resolution

plt.show()

from sklearn.metrics import roc_auc_score
auc = roc_auc_score(y_test, y_prob)
print(f"ROC AUC: {auc}")

import pandas as pd

# Example of creating unseen data as a DataFrame
unseen_data = pd.DataFrame({
    'gender': ['M', 'F', 'M', 'M', 'F', 'F'],
    'job_categories': ['STEM', 'Healthcare and Medicine', 'Education and Training', 'Media and Communications', 'Civilian Jobs', 'Arts and Culture'],
    'state': ['NY', 'CA', 'MO', 'FL', 'PA', 'TX'],
    'age': [28, 35, 22, 28, 31, 40],
    'rounded_amt': [150, 200, 1000, 250, 600, 220],
    'transaction_hour': [22, 23, 10, 11, 12, 8]
})

# Check the unseen data
print(unseen_data)
# Assuming X_train and y_train are available, fit the pipeline again
pipeline.fit(X_train, y_train)

# Now make predictions on unseen data
predictions = pipeline.predict(unseen_data)
print("Predictions on Unseen Data:", predictions)

probabilities = pipeline.predict_proba(unseen_data)
print("Prediction Probabilities:\n", probabilities)

# Example: Saving the pipeline (make sure this was done previously)
import joblib
joblib.dump(pipeline, 'fraud_detection_model.pkl')
# Example: Loading the entire pipeline
pipeline = joblib.load('fraud_detection_model.pkl')

# Proceed with prediction
predictions = pipeline.predict(unseen_data)
print("Predictions on Unseen Data:", predictions)
# Add predictions to the unseen data
unseen_data['predictions'] = predictions

# Display the data with predictions
print(unseen_data)
from sklearn.ensemble import RandomForestClassifier

pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', RandomForestClassifier(random_state=42, class_weight='balanced'))  # Add class_weight='balanced'
])

pip install imbalanced-learn
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as imbaPipeline

# Create a SMOTE object
smote = SMOTE(sampling_strategy='auto', random_state=42)

# Define your pipeline
pipeline = imbaPipeline(steps=[
    ('preprocessor', preprocessor),
    ('smote', smote),  # Add SMOTE after preprocessing
    ('classifier', RandomForestClassifier(random_state=42))
])

# Fit the model
pipeline.fit(X_train, y_train)

# Predict on the test set
predictions = pipeline.predict(X_test)
from imblearn.under_sampling import RandomUnderSampler

# Create a RandomUnderSampler object
undersampler = RandomUnderSampler(sampling_strategy='auto', random_state=42)

# Define your pipeline
pipeline = imbaPipeline(steps=[
    ('preprocessor', preprocessor),
    ('undersampler', undersampler),  # Add undersampling
    ('classifier', RandomForestClassifier(random_state=42))
])

# Fit the model
pipeline.fit(X_train, y_train)

# Predict on the test set
predictions = pipeline.predict(X_test)

from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

# Print classification report for precision, recall, f1-score, and support
print(classification_report(y_test, predictions))

# Print confusion matrix
print(confusion_matrix(y_test, predictions))

# Calculate accuracy score
accuracy = accuracy_score(y_test, predictions)
print(f"Accuracy: {accuracy}")

# Save the image
output_image_path = r"C:\Users\Ketki\Downloads\classification_report_output.png"
plt.savefig(output_image_path, bbox_inches='tight', dpi=300)
plt.close()

import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix

# Generate confusion matrix
cm = confusion_matrix(y_test, predictions)

# Plot confusion matrix
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=["No Fraud", "Fraud"], yticklabels=["No Fraud", "Fraud"])
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('Confusion Matrix')
# Save the plot as a PNG file
output_path = r"C:\Users\Ketki\Downloads\Confusion Matrix.png"  # Specify the desired output path
plt.savefig(output_path, format='png', dpi=300, bbox_inches='tight')  # Save as PNG with high resolution

plt.show()

# Assuming unseen_data is a dataframe or array with the same format as X_test
predictions_on_unseen = pipeline.predict(unseen_data)

# Print predictions for unseen data
print("Predictions on Unseen Data:", predictions_on_unseen)

# Adjust threshold
threshold = 0.7  # Example threshold
probabilities = pipeline.predict_proba(X_test)[:, 1]
predictions = (probabilities > threshold).astype(int)
# Get predicted probabilities for the positive class (Fraud)
probabilities = pipeline.predict_proba(X_test)[:, 1]
# Set the threshold
threshold = 0.7

# Convert probabilities to predictions based on the new threshold
predictions_thresholded = (probabilities > threshold).astype(int)
# Assuming unseen_data is a dataframe or array with the same format as X_test
predictions_on_unseen = pipeline.predict(unseen_data)

# Print predictions for unseen data
print("Predictions on Unseen Data:", predictions_on_unseen)
from sklearn.metrics import classification_report, confusion_matrix

# Evaluate the new predictions
print("Confusion Matrix:\n", confusion_matrix(y_test, predictions_thresholded))
print("\nClassification Report:\n", classification_report(y_test, predictions_thresholded))

# Save the image
output_image_path = r"C:\Users\Ketki\Downloads\classification_report Final_output.png"
plt.savefig(output_image_path, bbox_inches='tight', dpi=300)
plt.close()

import matplotlib.pyplot as plt
from sklearn.metrics import precision_recall_curve

# Get precision and recall values for various thresholds
precision, recall, thresholds_pr = precision_recall_curve(y_test, probabilities)

# Plot Precision-Recall vs. Threshold
plt.figure(figsize=(8, 6))
plt.plot(thresholds_pr, precision[:-1], label="Precision")
plt.plot(thresholds_pr, recall[:-1], label="Recall")
plt.xlabel("Threshold")
plt.ylabel("Precision / Recall")
plt.title("Precision-Recall vs Threshold")
plt.legend()
plt.grid()
plt.show()

thresholds = [0.3, 0.5, 0.7, 0.9]

for t in thresholds:
    predictions = (probabilities > t).astype(int)
    print(f"\nThreshold: {t}")
    print("Confusion Matrix:\n", confusion_matrix(y_test, predictions))
    print("\nClassification Report:\n", classification_report(y_test, predictions))


















