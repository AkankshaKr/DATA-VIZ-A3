import pandas as pd
from wordcloud import WordCloud
import matplotlib.pyplot as plt

# Load the dataset
file_path = r"D:\Data Visualization\Digital Society - A1\A1 Refined Dataset - Dataset.csv"  # Replace with your actual file path
df = pd.read_csv(file_path)

# Combine all job categories into a single string
text = ' '.join(df['category'].dropna().astype(str))

# Generate the word cloud
wordcloud = WordCloud(
    width=800,
    height=400,
    background_color='white',
    colormap='viridis',
    max_words=200
).generate(text)

# Plot the word cloud
plt.figure(figsize=(12, 8))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis('off')  # Turn off axes
plt.title('Word Cloud of Merchant Category (2020)', fontsize=16)
plt.show()











