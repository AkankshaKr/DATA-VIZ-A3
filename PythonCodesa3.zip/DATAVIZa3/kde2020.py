import pandas as pd

# Load the dataset
file_path = r"D:\Data Visualization\Digital Society - A1\A1 Refined Dataset - Dataset.csv"  #
df = pd.read_csv(file_path)

# Check the first few rows of the dataset to understand its structure
print(df.head())

# Assuming your dataframe is named df
fraud_transactions = df[df['is_fraud'] == 1][['amt']]

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde
from scipy.stats import mode

# Calculate mean, median, and mode
mean_amt = fraud_transactions['amt'].mean()
median_amt = fraud_transactions['amt'].median()
mode_amt = fraud_transactions['amt'].mode()[0]  # [0] to get the first mode

# Plot the bell-shaped graph
data = fraud_transactions['amt']
density = gaussian_kde(data)  # Kernel density estimation for smooth curve
x_vals = np.linspace(data.min(), data.max(), 1000)  # X-axis range
y_vals = density(x_vals)

plt.figure(figsize=(10, 6))
plt.plot(x_vals, y_vals, label='Density Curve', color='blue')
plt.axvline(mean_amt, color='red', linestyle='--', label=f'Mean: {mean_amt:.2f}')
plt.axvline(median_amt, color='green', linestyle='--', label=f'Median: {median_amt:.2f}')
plt.axvline(mode_amt, color='purple', linestyle='--', label=f'Mode: {mode_amt:.2f}')

# Add labels and legend
plt.title('Distribution of Rounded Amounts of 2020(Fraud Transactions)')
plt.xlabel('Amount')
plt.ylabel('Density')
plt.legend()
plt.grid(True)

# Show the plot
plt.show()
