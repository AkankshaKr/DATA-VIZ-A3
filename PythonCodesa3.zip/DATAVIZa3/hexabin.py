import pandas as pd
import matplotlib.pyplot as plt
import geopandas as gpd
from shapely.geometry import Point

# Load dataset
data = pd.read_csv("C:/Users/Acer/Downloads/updated_dataset.csv")

# Check the columns to ensure the necessary columns are available
print(data.columns)

# Extract relevant columns
latitudes = data['lat']
longitudes = data['long']
is_fraud = data['is_fraud']

# Create a figure and axis for the hexbin plot
plt.figure(figsize=(12, 8))

# Create the hexbin plot with latitude and longitude data, coloring by fraud status
# We will use 'is_fraud' for the color of each hexagon
hb = plt.hexbin(longitudes, latitudes, C=is_fraud, gridsize=30, cmap='coolwarm', mincnt=1)

# Add colorbar to show fraud vs non-fraud
plt.colorbar(hb, label='Fraud (0 = Non-Fraud, 1 = Fraud)')

# Add labels and title
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.title('Geographic Hexbin Plot of Fraud vs Non-Fraud Transactions')

# Show the plot
plt.show()
