import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Load the dataset
file_path = r"C:\Users\Acer\Downloads\updated_dataset.csv"  # Replace with your dataset path
df = pd.read_csv(file_path)

# Filter for the selected states
selected_states = ['NY', 'TX', 'OH', 'MO', 'FL', 'PA']
df_states = df[df['state'].isin(selected_states)]

# Count unique credit card numbers for fraudulent and non-fraudulent transactions per state
fraud_counts = df_states[df_states['is_fraud'] == 1].groupby('state')['cc_num'].nunique()
non_fraud_counts = df_states[df_states['is_fraud'] == 0].groupby('state')['cc_num'].nunique()

# Combine the counts into a single DataFrame
dumbbell_data = pd.DataFrame({
    'Non-Fraudulent': non_fraud_counts,
    'Fraudulent': fraud_counts
}).fillna(0)

# Plot the dumbbell chart
fig, ax = plt.subplots(figsize=(10, 6))
for idx, row in dumbbell_data.iterrows():
    ax.plot([row['Non-Fraudulent'], row['Fraudulent']], [idx, idx], 'o-', color='gray', markersize=8)
    ax.text(row['Non-Fraudulent'], idx, f"{int(row['Non-Fraudulent'])}", va='center', ha='right', color='blue')
    ax.text(row['Fraudulent'], idx, f"{int(row['Fraudulent'])}", va='center', ha='left', color='red')

# Customize the chart
ax.set_yticks(np.arange(len(dumbbell_data.index)))
ax.set_yticklabels(dumbbell_data.index, fontsize=12)
ax.set_xlabel('Number of Unique Credit Card Numbers', fontsize=14)
ax.set_title('Number of Unique Credit Card Numbers by Fraud Status Across States', fontsize=16)
ax.axvline(x=0, color='black', linewidth=0.5)
plt.grid(axis='x', linestyle='--', alpha=0.7)

# Add legend
plt.scatter([], [], c='blue', label='Non-Fraudulent', s=50)
plt.scatter([], [], c='red', label='Fraudulent', s=50)
plt.legend(fontsize=12)

plt.tight_layout()
plt.show()

