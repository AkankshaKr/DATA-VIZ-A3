import pandas as pd
import plotly.graph_objects as go

# Load the dataset
file_path = r"C:\Users\Acer\Downloads\updated_dataset.csv"
data = pd.read_csv(file_path)

# Filter the data for the specified states
states = ['TX', 'NY', 'PA', 'OH', 'FL', 'MO']
filtered_data = data[data['state'].isin(states)]

# Group by gender and state to find fraud occurrences
fraud_data = filtered_data.groupby(['state', 'gender']).size().reset_index(name='fraud_count')

# Group by state and get the average lat and long for each state
state_coords = filtered_data.groupby('state')[['lat', 'long']].mean().reset_index()

# Merge fraud data with state coordinates
fraud_data_with_coords = pd.merge(fraud_data, state_coords, on='state')

# Create an empty figure for plotting
fig = go.Figure()

# Adjust the domain mapping with more precise positions to place pie charts on the states
# Updated x, y domain values for better pie chart placement
state_domains = {
    'TX': {'x': [0.40, 0.50], 'y': [0.30, 0.40]},  # Closer to Texas
    'NY': {'x': [0.63, 0.73], 'y': [0.70, 0.80]},  # Move above New York state
    'PA': {'x': [0.69, 0.73], 'y': [0.55, 0.65]},  # Half on PA and half below
    'OH': {'x': [0.59, 0.70], 'y': [0.48, 0.58]},  # Exactly on Ohio
    'FL': {'x': [0.62, 0.72], 'y': [0.20, 0.30]},  # Near Florida (no change)
    'MO': {'x': [0.48, 0.58], 'y': [0.52, 0.63]},  # Near Missouri (no change)
}

# Plot pie charts on the map
for state in states:
    # Filter fraud data for the specific state
    state_fraud_data = fraud_data_with_coords[fraud_data_with_coords['state'] == state]

    # Pie chart values (fraud count for male and female)
    values = state_fraud_data['fraud_count'].values
    labels = state_fraud_data['gender'].values

    # Latitude and longitude for the state
    lat = state_fraud_data['lat'].values[0]
    long = state_fraud_data['long'].values[0]

    # Add pie chart for the state with adjusted domain
    fig.add_trace(go.Pie(
        values=values,
        labels=labels,
        hoverinfo='label+percent+name',  # Only show labels and percentage when hovering
        domain=state_domains[state],  # Adjust domain for each state
        name=f'Fraud in {state}',  # The name of the state for the hover info
        hole=0.3,
        textinfo='none',  # No text info on the pie chart
        showlegend=True  # Keep the pie chart in the legend to show gender labels
    ))

    # Add a scatter geo marker for each state's location
    fig.add_trace(go.Scattergeo(
        locationmode='USA-states',
        lon=[long],
        lat=[lat],
        hoverinfo='text',
        text=f'{state} Fraud Breakdown',
        marker=dict(
            size=0  # Make the marker invisible
        ),
        showlegend=False  # Hide scatter geo marker from the legend
    ))

    # Add state name text directly on the map
    fig.add_trace(go.Scattergeo(
        locationmode='USA-states',
        lon=[long],
        lat=[lat],
        hoverinfo='none',  # Disable hover info for state name
        text=state,  # Display the state name
        mode='text',  # Text mode for state names
        textfont=dict(
            size=14,
            color='black'
        ),
        showlegend=False  # Hide the state name text from the legend
    ))

# Update the layout for the map appearance
fig.update_layout(
    title_text='Fraud Occurrence by Gender in Selected States',
    showlegend=True,  # Ensure the legend is visible to show gender
    geo=dict(
        scope='usa',
        projection=go.layout.geo.Projection(type='albers usa'),
        showland=True,
        landcolor="rgb(250, 250, 250)",
        subunitcolor="rgb(100, 217, 217)",
        countrycolor="rgb(217, 100, 217)",
    )
)

# Show the interactive map
fig.show()
