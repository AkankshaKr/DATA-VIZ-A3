import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load the dataset from the CSV file
file_path = r"C:\Users\Acer\Downloads\updated_dataset.csv"  # Replace with your actual file path
df = pd.read_csv(file_path)

# Check for missing values in relevant columns
print(f"Missing values in 'category': {df['category'].isna().sum()}")
print(f"Missing values in 'rounded_amt': {df['rounded_amt'].isna().sum()}")
print(f"Missing values in 'is_fraud': {df['is_fraud'].isna().sum()}")

# Drop rows where 'job_categories', 'rounded_amt', or 'is_fraud' are missing
df = df.dropna(subset=['category', 'rounded_amt', 'is_fraud'])  # Ensure both 'category' and 'rounded_amt' are available

# Map 'is_fraud' to colors (0 -> red, 1 -> yellow)
fraud_palette = {0: 'red', 1: 'yellow'}

# Plotting the density scatter plot for Job Category vs Transaction Amount
plt.figure(figsize=(12, 8))

# Using seaborn's scatterplot with customized hue (fraud status)
sns.scatterplot(data=df, x='category', y='rounded_amt', hue='is_fraud', palette=fraud_palette, s=100, alpha=0.7)

# Adding titles and labels for better understanding
plt.title('Density Scatter Plot of category vs Transaction Amount by Fraud Status', fontsize=16)
plt.xlabel('category', fontsize=14)
plt.ylabel('Transaction Amount (Rounded)', fontsize=14)

# Rotate the x-axis labels vertically
plt.xticks(rotation=90)

# Display the plot
plt.show()


