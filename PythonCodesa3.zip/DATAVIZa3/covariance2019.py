import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler, LabelEncoder

# Load your dataset
file_path = r"C:\Users\Acer\Downloads\updated_dataset.csv"
data = pd.read_csv(file_path)

# Drop non-informative or high-cardinality columns
columns_to_drop = ['Unnamed', 'cc_num', 'unix_time', 'zip']  # Adjust as needed
data = data.drop(columns=columns_to_drop, errors='ignore')

# Identify categorical and numeric columns
categorical_columns = data.select_dtypes(include=['object']).columns
numeric_columns = data.select_dtypes(include=['number']).columns

# Handle high cardinality categorical columns using Label Encoding
label_encoded_data = data.copy()
for col in categorical_columns:
    if data[col].nunique() > 100:  # High cardinality threshold
        label_encoder = LabelEncoder()
        label_encoded_data[col] = label_encoder.fit_transform(data[col])
    else:
        # Perform one-hot encoding for low-cardinality categorical columns
        dummies = pd.get_dummies(data[col], prefix=col, drop_first=True)
        label_encoded_data = pd.concat([label_encoded_data, dummies], axis=1)
        label_encoded_data = label_encoded_data.drop(columns=[col])

# Select only numeric columns (including processed categorical ones)
numeric_data = label_encoded_data.select_dtypes(include=['number'])

# Normalize the numeric data
scaler = StandardScaler()
normalized_data = pd.DataFrame(scaler.fit_transform(numeric_data), columns=numeric_data.columns)

# Calculate the covariance matrix
covariance_matrix = normalized_data.cov()

# Visualize the covariance matrix with annotations and rounded values
plt.figure(figsize=(15, 12))  # Adjust figure size
sns.heatmap(
    covariance_matrix,
    annot=True,         # Enable annotations
    fmt=".2f",         # Format to 2 decimal places
    cmap="coolwarm",
    cbar=True,
    xticklabels=True,
    yticklabels=True
)

# Rotate x-axis labels
plt.xticks(rotation=45, ha="right")
plt.yticks(rotation=0)

# Add title
plt.title("Optimized Covariance Matrix Heatmap")
plt.tight_layout()  # Ensure the plot fits well
plt.show()
