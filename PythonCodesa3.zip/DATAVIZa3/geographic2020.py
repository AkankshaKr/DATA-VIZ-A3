import pandas as pd
import plotly.express as px

# Load the dataset
file_path = r"D:\Data Visualization\Digital Society - A1\A1 Refined Dataset - Dataset.csv"
data = pd.read_csv(file_path)

# Filter data for fraud cases
fraud_data = data[data['is_fraud'] == 1]

# Group by state to calculate the number of fraud cases per state
fraud_by_state = fraud_data.groupby('state').size().reset_index(name='fraud_count')

# Create a choropleth map for fraud by state
fig = px.choropleth(
    fraud_by_state,
    locations='state',                # Column with state names
    locationmode='USA-states',        # Specify USA state codes
    color='fraud_count',              # Color by the count of fraud cases
    color_continuous_scale='Reds',    # Heatmap color scale (e.g., Reds)
    scope='usa',                      # Restrict map to the USA
    title="Heatmap of Fraud Cases by State in 2020",
    hover_name="state"                # Display state name in the hover tooltip
)

# Add state names as text labels using scatter_geo
state_coordinates = {
    "Alabama": (32.806671, -86.791130),
    "Alaska": (61.370716, -152.404419),
    "Arizona": (33.729759, -111.431221),
    "Arkansas": (34.868905, -92.373123),
    "California": (36.116203, -119.681564),
    # Add coordinates for other states here
}

# Create a scatter_geo trace for state labels
annotations = []
for i, row in fraud_by_state.iterrows():
    state = row['state']
    if state in state_coordinates:
        lat, lon = state_coordinates[state]
        annotations.append(dict(
            type='scattergeo',
            lon=[lon],
            lat=[lat],
            text=[state],
            mode='text',
            showlegend=False,
            textfont=dict(size=10, color="black"),  # Set font size and color
            opacity=0.8
        ))

# Add annotations as a separate trace
for annotation in annotations:
    fig.add_trace(annotation)

# Display the map
fig.show()
